---
name: shawn-design
description: Use this skill to generate well-branded interfaces and assets for SHAWN, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

SHAWN is a premium, minimal, editorial lifestyle brand (apparel first, lifestyle house long-term). Warm neutral palette, Marcellus serif display, Jost sans body, the "Lens" symbol. No bright colour, no emoji, no em dashes in copy.

Key files:
- `readme.md` — full brand strategy, voice, visual foundations, iconography.
- `styles.css` — link this one file to pick up every token and font.
- `assets/shawn-symbol.svg`, `assets/shawn-symbol-solid.svg` — the Lens mark.
- `tokens/` — colour, type, spacing, font tokens.
- `components/core/` — Button, Eyebrow, Tag, Input, ProductCard (React).
- `ui_kits/website/` — interactive storefront reference.
- `guidelines/` — specimen cards for colour, type, spacing, and brand applications.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets out and create static HTML files for the user to view. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without other guidance, ask them what they want to build or design, ask a few focused questions, then act as an expert designer who outputs HTML artifacts or production code, depending on the need.
