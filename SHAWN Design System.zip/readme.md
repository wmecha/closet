# SHAWN — Brand & Design System

> A future international lifestyle company that launches first through fashion.
> The master brand is **SHAWN**. The first business unit is **SHAWN Apparel**.

---

## 1. Brand Strategy

**Positioning.** SHAWN sells a carefully curated lifestyle, not products. Customers buy taste, confidence, and a sense of modern living. Fashion is the opening chapter, not the whole book.

**Essence.** Curated modern living.

**Promise.** Everything SHAWN touches feels considered, calm, and quietly luxurious.

**Pillars.**
- Confidence. Quiet, not loud. We never shout.
- Taste. A discerning point of view. We edit so the customer does not have to.
- Elegance. Restraint, proportion, and warmth.
- Curation. A tightly chosen collection beats an endless catalogue.
- Modern living. Designed for a full, mobile, digital life.

**Personality.** Premium, minimal, modern, sophisticated, aspirational, timeless, editorial, international, design led. Feminine in sensibility without being overtly feminine.

**Customer.** Women aged 20 to 40. Style conscious and digitally active. Interested in fashion, beauty, home, travel, and modern lifestyle products. She values quality over quantity and design over trend.

**What SHAWN is not.** Not fast fashion. Not streetwear. Not loud luxury. Not trend chasing. Not thrift or vintage. Not generic boutique. Never gold on black luxury cliché.

**Brand architecture.**
- Master brand: **SHAWN**
- Launch unit: **SHAWN Apparel**
- Designed to extend to: SHAWN Beauty, SHAWN Home, SHAWN Living, SHAWN Studio, SHAWN Collection, plus retail, e-commerce, wellness, accessories, and future luxury collaborations.
- The wordmark and the Lens symbol stay constant. Divisions are set in a smaller label beneath or beside the wordmark using the same Marcellus tracking. The system never forks visually across divisions; it scales.

**Africa ambition.** SHAWN is built to become one of Africa's most respected modern lifestyle brands, presented to the world with international polish.

---

## 2. The Mark — "The Lens"

The symbol is an abstract **lens / aperture**: two nested, tilted almond forms. It is not a letter, monogram, hanger, bag, dress, or heel.

It communicates, without depicting:
- **Taste and curation** — a discerning eye, a lens that selects.
- **Movement and elegance** — the tilt gives it motion and poise.
- **Refinement and timelessness** — pure geometry, no era.

It is strong enough to stand alone, embroiders cleanly, and reduces to a favicon.

Master files:
- `assets/shawn-symbol.svg` — primary, stroked, `currentColor`.
- `assets/shawn-symbol-solid.svg` — filled ring for embroidery, app icon, small sizes, single colour.

**Primary lockup** is vertical: the Lens above the wordmark **SHAWN** set in Marcellus with wide tracking. A horizontal secondary lockup places the Lens left of the wordmark. The Lens may always be used independently.

---

## 3. Content Fundamentals (voice & copy)

**Tone.** Calm, assured, editorial. Speaks like a trusted, well travelled friend with impeccable taste. Never hard sells. Confidence shown through restraint.

**Casing.**
- The brand name is always uppercase: **SHAWN**.
- Eyebrows, labels, nav, and buttons use uppercase with wide letter spacing: `THE EDIT`, `ADD TO BAG`, `NEW ARRIVALS`.
- Headlines and editorial copy use sentence case in serif: `Made to be kept.`
- Body copy is sentence case.

**Person.** Address the customer as "you" sparingly and warmly. Speak about the brand as "SHAWN" or "we", used lightly. Let products and imagery carry most of the message.

**Punctuation.** No em dashes anywhere. Use a period or a comma. Short sentences. White space is part of the writing.

**Vocabulary.** edit, curated, considered, essential, the season, made to be kept, quietly, in good taste, the collection, objects for living. Avoid hype words: sale, deal, exclusive drop, must have, hurry, limited time.

**Emoji.** Never. No emoji in any brand surface.

**Examples.**
- Hero: `The considered wardrobe.` / `A short edit of pieces made to be kept.`
- Product: `Relaxed wool trouser in stone. Cut for ease, made to last.`
- CTA: `EXPLORE THE EDIT` · `ADD TO BAG` · `BOOK AN APPOINTMENT`
- Newsletter: `Join the list. First access to each new edit.`
- Thank you card: `Thank you for choosing SHAWN. Wear it well.`

---

## 4. Visual Foundations

**Overall feel.** Editorial, generous, warm, quiet. Lots of negative space. The page breathes. Imagery leads; type supports.

**Colour.** A warm neutral spine from Ivory to Ink, with two muted earth accents (Clay, Olive). No bright colour anywhere. Ivory (`--shawn-ivory`) is the default canvas; Ink (`--shawn-ink`) is the default text and the inverse surface. Accents appear in tiny doses (a line, a tag, a hover), never as fills of large areas. Full tokens in `tokens/colors.css`.

**Type.** Marcellus for the wordmark and editorial display. Cormorant Garamond italic for pull quotes and flourish. Jost for body, UI, and labels, always with open tracking. Big serif headlines against small, wide tracked sans labels is the signature contrast. Tokens in `tokens/typography.css`.

**Spacing.** A 4px base scale, used generously. Sections are tall (`--space-120` / `--space-160`). Components are calm and roomy. Density is low by design.

**Backgrounds.** Solid warm neutrals only. Ivory, Bone, or Ink. No gradients, no patterns, no texture overlays, no blur scrims. Full bleed photography is the main "texture". Imagery is the colour.

**Borders & dividers.** Hairlines, near black at low opacity (`--line-hairline`). Thin rules separate editorial blocks. Borders preferred over shadows.

**Corner radii.** Almost square. Buttons and inputs use `--radius-md` (4px) or less; cards are square or 2px. Pills only for small filter chips. Editorial, not app like.

**Shadows.** Whisper soft and warm toned, used rarely. Cards usually sit on borders or flat colour, not shadow. When elevation is needed (menus, dialogs), `--shadow-md` / `--shadow-lg`. No hard or coloured shadows.

**Cards.** Mostly flat: a white or Bone surface with a hairline border, square corners, image first. No heavy chrome. No coloured left border accents.

**Motion.** Slow, soft, confident. Fades and gentle rises (8 to 16px), `--ease-entrance`. Durations `--dur-base` to `--dur-slow`. Images zoom slowly on hover (scale 1.03 over 600ms). No bounce, no spring, no parallax tricks. Respect reduced motion.

**Hover states.** Links and labels: opacity to ~0.6, or an underline that draws in. Buttons: a quiet tonal shift (Ink to Espresso), never a colour pop. Image cards: slow zoom plus a fading caption.

**Press states.** A subtle darken and a 1px settle. No large scale changes.

**Transparency & blur.** Used sparingly. A sticky header may use a translucent Ivory with light backdrop blur once scrolled. Otherwise surfaces are opaque.

**Imagery vibe.** Warm, natural light. Soft film like tonality, gentle grain acceptable. Muted, earthy palette that matches the brand neutrals. Editorial composition, lots of air. Never oversaturated, never cool blue, never harsh studio flash. See Photography Direction card.

**Layout rules.** Wide editorial grid (`--content-max` 1280px) with a generous gutter. Asymmetry welcome. Type set left or centred, never justified to hard edges everywhere. The wordmark sits in clear space equal to the Lens height on all sides.

---

## 5. Iconography

Approach: **minimal line icons, 1.5px stroke, rounded joins, no fill**, matching the thin elegance of the Lens. Icons are quiet and few. They never compete with imagery or type.

- System icons (bag, search, account, close, chevron, plus, minus): use **Lucide** (CDN: `https://unpkg.com/lucide@latest`), stroke width set to 1.5, colour `currentColor` inheriting `--text-primary`. Lucide's thin, rounded geometric line style matches SHAWN. This is a documented substitute for a bespoke set; a custom icon family can replace it later with the same metrics.
- The Lens symbol (`assets/shawn-symbol.svg`) is brand furniture, not a UI icon. Do not use it as a button glyph.
- No emoji, ever. No unicode dingbats as icons. No duotone or filled icon styles.
- Sizes: 16, 20, 24px. Touch targets at least 44px.

---

## 6. Index / Manifest

Root:
- `styles.css` — global entry point. Link this one file. Imports all tokens and fonts.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`.
- `assets/` — `shawn-symbol.svg`, `shawn-symbol-solid.svg`, brand imagery.
- `readme.md` — this document.
- `SKILL.md` — Agent Skills wrapper.

Specimen cards (Design System tab):
- `guidelines/colors/` — Colors group cards.
- `guidelines/type/` — Type group cards.
- `guidelines/spacing/` — Spacing group cards.
- `guidelines/brand/` — Brand group: logo variants, packaging, social, photography, architecture.

Components (`components/core/`): Button, Eyebrow, Tag, Input, ProductCard. Each is `<Name>.jsx` + `<Name>.d.ts` + `<Name>.prompt.md`, with one card HTML per directory. Button and ProductCard are also exposed as starting points.

Templates (`templates/`): `editorial-campaign/` — "Editorial Campaign", a SHAWN campaign landing page (hero, the edit trio, signup) consuming projects can copy. Each template is a `.dc.html` entry with a sibling `ds-base.js` that links `styles.css` and the compiled bundle.

UI kit (`ui_kits/website/`): editorial e-commerce — Home, Collection, Product, About. Interactive `index.html` with sticky header, cart drawer, and routing.

> Sources: none external. This identity was created from the SHAWN brief; there was no attached codebase or Figma. Fonts are Google Fonts (Marcellus, Cormorant Garamond, Jost) standing in for a future licensed pairing. Icons are Lucide via CDN. All flagged in the closing notes.
