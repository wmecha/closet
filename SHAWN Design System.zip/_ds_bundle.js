/* @ds-bundle: {"format":3,"namespace":"SHAWNDesignSystem_ef7ee7","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"ProductCard","sourcePath":"components/core/ProductCard.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"}],"sourceHashes":{"components/core/Button.jsx":"0e0ad8d8f915","components/core/Eyebrow.jsx":"5e412bca430a","components/core/Input.jsx":"dd69c1054517","components/core/ProductCard.jsx":"bde9dc852c3e","components/core/Tag.jsx":"5dc331b64124","ui_kits/website/About.jsx":"0a8d8d78ed98","ui_kits/website/App.jsx":"0d0d2bd00ee2","ui_kits/website/Collection.jsx":"8cf1cbf93e9d","ui_kits/website/Home.jsx":"73d1ee981297","ui_kits/website/Product.jsx":"25b5997a5168","ui_kits/website/data.js":"aeb03fb21227"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SHAWNDesignSystem_ef7ee7 = window.SHAWNDesignSystem_ef7ee7 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SHAWN Button — quiet, editorial, uppercase with wide tracking.
 * Variants: primary (ink fill), secondary (outline), ghost (underlined link).
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  as = 'button',
  style,
  ...rest
}) {
  const pad = size === 'sm' ? '10px 20px' : size === 'lg' ? '18px 40px' : '14px 30px';
  const fs = size === 'sm' ? '10.5px' : '11.5px';
  const base = {
    fontFamily: 'var(--font-sans)',
    fontSize: fs,
    fontWeight: 500,
    letterSpacing: '0.16em',
    textTransform: 'uppercase',
    padding: pad,
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    width: fullWidth ? '100%' : 'auto',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '10px',
    transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard), opacity var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)',
    opacity: disabled ? 0.4 : 1,
    textDecoration: 'none',
    lineHeight: 1
  };
  const variants = {
    primary: {
      background: 'var(--shawn-ink)',
      color: 'var(--shawn-ivory)',
      border: '1px solid var(--shawn-ink)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--shawn-ink)',
      border: '1px solid var(--line-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--shawn-ink)',
      border: '1px solid transparent',
      padding: size === 'sm' ? '6px 2px' : '8px 2px',
      borderRadius: 0
    }
  };
  const onEnter = e => {
    if (disabled) return;
    if (variant === 'primary') e.currentTarget.style.background = 'var(--shawn-espresso)';
    if (variant === 'secondary') e.currentTarget.style.borderColor = 'var(--shawn-ink)';
    if (variant === 'ghost') {
      e.currentTarget.style.opacity = '0.6';
      e.currentTarget.style.boxShadow = 'inset 0 -1px 0 var(--shawn-ink)';
    }
  };
  const onLeave = e => {
    if (disabled) return;
    if (variant === 'primary') e.currentTarget.style.background = 'var(--shawn-ink)';
    if (variant === 'secondary') e.currentTarget.style.borderColor = 'var(--line-strong)';
    if (variant === 'ghost') {
      e.currentTarget.style.opacity = '1';
      e.currentTarget.style.boxShadow = 'none';
    }
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      ...base,
      ...variants[variant],
      ...style
    },
    disabled: as === 'button' ? disabled : undefined,
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SHAWN Eyebrow — small wide-tracked uppercase label above headings. */
function Eyebrow({
  children,
  color = 'accent',
  as = 'div',
  style,
  ...rest
}) {
  const colors = {
    accent: 'var(--shawn-clay)',
    muted: 'var(--shawn-taupe)',
    ink: 'var(--shawn-ink)',
    light: 'var(--text-on-inverse-soft)'
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-micro)',
      fontWeight: 500,
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: colors[color] || color,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SHAWN Input — underline-only text field with a wide-tracked label. */
function Input({
  label,
  id,
  type = 'text',
  style,
  containerStyle,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '8px',
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: type,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-primary)',
      background: 'transparent',
      border: 'none',
      borderBottom: `1px solid ${focused ? 'var(--shawn-ink)' : 'var(--line-soft)'}`,
      padding: '8px 0',
      outline: 'none',
      transition: 'border-color var(--dur-fast) var(--ease-standard)',
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/ProductCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SHAWN ProductCard — image-first editorial product tile with slow hover zoom. */
function ProductCard({
  name,
  price,
  category,
  badge,
  image,
  imageColor = 'var(--shawn-sand)',
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      cursor: onClick ? 'pointer' : 'default',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: imageColor,
      aspectRatio: '3 / 4'
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block',
      transform: hover ? 'scale(1.04)' : 'scale(1)',
      transition: 'transform var(--dur-slow) var(--ease-standard)'
    }
  }), badge && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '14px',
      left: '14px',
      fontSize: '9.5px',
      fontWeight: 500,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--shawn-ink)',
      background: 'var(--shawn-ivory)',
      padding: '5px 10px'
    }
  }, badge)), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: '16px',
      display: 'flex',
      flexDirection: 'column',
      gap: '5px'
    }
  }, category && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '10px',
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, category), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-title)',
      color: 'var(--text-primary)',
      lineHeight: 1.2
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body)',
      color: 'var(--text-secondary)',
      letterSpacing: '0.02em'
    }
  }, price)));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SHAWN Tag — small uppercase chip for status, category, or filter. */
function Tag({
  children,
  variant = 'outline',
  style,
  ...rest
}) {
  const variants = {
    outline: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      border: '1px solid var(--line-soft)'
    },
    solid: {
      background: 'var(--shawn-ink)',
      color: 'var(--shawn-ivory)',
      border: '1px solid var(--shawn-ink)'
    },
    accent: {
      background: 'transparent',
      color: 'var(--shawn-clay)',
      border: '1px solid var(--shawn-clay)'
    },
    bare: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      border: '1px solid transparent',
      padding: '4px 0'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-sans)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      padding: '5px 11px',
      borderRadius: 'var(--radius-pill)',
      lineHeight: 1,
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/About.jsx
try { (() => {
// SHAWN — About screen
function About({
  navigate
}) {
  const {
    Eyebrow,
    Button
  } = window.SHAWNDesignSystem_ef7ee7;
  const pillars = [{
    t: 'Confidence',
    d: 'Quiet, never loud. We let the work speak.'
  }, {
    t: 'Taste',
    d: 'A discerning point of view. We edit so you do not have to.'
  }, {
    t: 'Curation',
    d: 'A tightly chosen collection beats an endless catalogue.'
  }, {
    t: 'Modern living',
    d: 'Designed for a full, mobile, considered life.'
  }];
  const divisions = ['Apparel', 'Beauty', 'Home', 'Living', 'Studio'];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '120px var(--gutter)',
      textAlign: 'center',
      background: 'var(--shawn-bone)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: '26px',
      display: 'block'
    }
  }, "The House of SHAWN"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 'clamp(2.4rem, 4.4vw, 4rem)',
      lineHeight: 1.15,
      margin: '0 auto',
      maxWidth: '880px',
      color: 'var(--shawn-ink)'
    }
  }, "A modern lifestyle house, beginning with fashion.")), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '110px var(--gutter)',
      display: 'grid',
      gridTemplateColumns: '1fr 1.2fr',
      gap: '80px',
      alignItems: 'center',
      maxWidth: 'var(--content-max)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--shawn-stone)',
      aspectRatio: '4 / 5'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: '20px',
      display: 'block'
    }
  }, "Our Story"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-editorial)',
      fontStyle: 'italic',
      fontSize: '26px',
      lineHeight: 1.45,
      color: 'var(--shawn-espresso)',
      margin: '0 0 26px',
      fontWeight: 500
    }
  }, "SHAWN is built on a simple belief. That a life well lived is a curated one."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      lineHeight: 1.75,
      color: 'var(--shawn-espresso)',
      margin: '0 0 18px',
      maxWidth: '480px'
    }
  }, "We begin with apparel, a short edit of pieces made to be kept. From there we grow into the everyday objects of a considered life. Beauty, home, and the spaces in between."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      lineHeight: 1.75,
      color: 'var(--shawn-espresso)',
      margin: 0,
      maxWidth: '480px'
    }
  }, "Our ambition is international, our roots are proudly African, and our standard is timeless."))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '0 var(--gutter) 110px',
      maxWidth: 'var(--content-max)',
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: '0',
      borderTop: '1px solid var(--line-soft)'
    }
  }, pillars.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: p.t,
    style: {
      padding: '34px 28px 34px 0',
      borderRight: i < 3 ? '1px solid var(--line-hairline)' : 'none',
      paddingLeft: i > 0 ? '28px' : 0
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: '22px',
      margin: '0 0 12px',
      color: 'var(--shawn-ink)'
    }
  }, p.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '13.5px',
      lineHeight: 1.65,
      color: 'var(--shawn-taupe)',
      margin: 0
    }
  }, p.d))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--shawn-ink)',
      padding: '110px var(--gutter)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: "light",
    style: {
      marginBottom: '40px',
      display: 'block'
    }
  }, "One House, Many Worlds"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0',
      justifyContent: 'center',
      flexWrap: 'wrap',
      maxWidth: '900px',
      margin: '0 auto'
    }
  }, divisions.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: d,
    style: {
      fontFamily: 'var(--font-wordmark)',
      letterSpacing: '0.2em',
      fontSize: '16px',
      color: i === 0 ? 'var(--shawn-ivory)' : 'var(--text-on-inverse-soft)',
      padding: '0 26px',
      borderRight: i < divisions.length - 1 ? '1px solid var(--line-on-inverse)' : 'none',
      opacity: i === 0 ? 1 : 0.7
    }
  }, "SHAWN", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '11px',
      letterSpacing: '0.24em'
    }
  }, d.toUpperCase())))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '12px',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--text-on-inverse-soft)',
      marginTop: '44px'
    }
  }, "Apparel is live. The rest is coming.")));
}
window.About = About;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/About.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/App.jsx
try { (() => {
// SHAWN — App shell: header, cart drawer, footer, routing
const {
  useState,
  useEffect,
  useRef
} = React;
function Icon({
  name,
  size = 19
}) {
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      display: 'inline-flex'
    }
  });
}
function Header({
  navigate,
  route,
  bagCount,
  openBag
}) {
  const link = (label, to) => /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate(to),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      fontWeight: 500,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: route === to ? 'var(--shawn-ink)' : 'var(--text-secondary)',
      padding: '4px 0',
      transition: 'color var(--dur-fast) var(--ease-standard)'
    },
    onMouseEnter: e => e.currentTarget.style.color = 'var(--shawn-ink)',
    onMouseLeave: e => e.currentTarget.style.color = route === to ? 'var(--shawn-ink)' : 'var(--text-secondary)'
  }, label);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: 'rgba(247,242,233,0.86)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--line-hairline)',
      display: 'grid',
      gridTemplateColumns: '1fr auto 1fr',
      alignItems: 'center',
      padding: '20px var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: '30px'
    }
  }, link('Shop', 'collection'), link('About', 'about')), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('home'),
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '7px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '26px',
      height: '26px',
      color: 'var(--shawn-ink)'
    },
    dangerouslySetInnerHTML: {
      __html: SHAWN_MARK
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-wordmark)',
      fontSize: '17px',
      letterSpacing: '0.4em',
      paddingLeft: '0.4em',
      color: 'var(--shawn-ink)',
      lineHeight: 1
    }
  }, "SHAWN")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '22px',
      justifyContent: 'flex-end',
      alignItems: 'center',
      color: 'var(--shawn-ink)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: iconBtn,
    "aria-label": "Search"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search"
  })), /*#__PURE__*/React.createElement("button", {
    style: iconBtn,
    "aria-label": "Account"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user"
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      ...iconBtn,
      position: 'relative'
    },
    "aria-label": "Bag",
    onClick: openBag
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shopping-bag"
  }), bagCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '-6px',
      right: '-8px',
      background: 'var(--shawn-clay)',
      color: 'var(--shawn-ivory)',
      fontFamily: 'var(--font-sans)',
      fontSize: '9px',
      fontWeight: 500,
      minWidth: '15px',
      height: '15px',
      borderRadius: '999px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '0 3px'
    }
  }, bagCount))));
}
const iconBtn = {
  background: 'none',
  border: 'none',
  cursor: 'pointer',
  color: 'inherit',
  padding: 0,
  display: 'inline-flex'
};
function CartDrawer({
  open,
  items,
  onClose,
  removeItem,
  navigate
}) {
  const total = items.reduce((s, it) => s + parseFloat(it.price.replace(/[^0-9.]/g, '')), 0);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(26,23,20,0.36)',
      zIndex: 60,
      opacity: open ? 1 : 0,
      pointerEvents: open ? 'auto' : 'none',
      transition: 'opacity var(--dur-base) var(--ease-standard)'
    }
  }), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'fixed',
      top: 0,
      right: 0,
      bottom: 0,
      width: '420px',
      maxWidth: '90vw',
      zIndex: 61,
      background: 'var(--shawn-ivory)',
      boxShadow: 'var(--shadow-lg)',
      transform: open ? 'translateX(0)' : 'translateX(100%)',
      transition: 'transform var(--dur-base) var(--ease-entrance)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '26px 30px',
      borderBottom: '1px solid var(--line-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      fontWeight: 500,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      color: 'var(--shawn-ink)'
    }
  }, "Your Bag \xB7 ", items.length), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      ...iconBtn,
      color: 'var(--shawn-ink)'
    },
    "aria-label": "Close"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '12px 30px'
    }
  }, items.length === 0 ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '14px',
      color: 'var(--text-secondary)',
      textAlign: 'center',
      marginTop: '60px',
      lineHeight: 1.7
    }
  }, "Your bag is quiet for now.", /*#__PURE__*/React.createElement("br", null), "The edit is waiting.") : items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: '16px',
      padding: '20px 0',
      borderBottom: '1px solid var(--line-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '68px',
      height: '88px',
      background: it.color,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '16px',
      color: 'var(--shawn-ink)',
      marginBottom: '4px'
    }
  }, it.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      letterSpacing: '0.06em',
      color: 'var(--text-secondary)',
      marginBottom: '10px'
    }
  }, "Size ", it.size), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '14px',
      color: 'var(--shawn-espresso)'
    }
  }, it.price)), /*#__PURE__*/React.createElement("button", {
    onClick: () => removeItem(i),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '10px',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      alignSelf: 'flex-start'
    }
  }, "Remove")))), items.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 30px 30px',
      borderTop: '1px solid var(--line-soft)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: '18px',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '11px',
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)'
    }
  }, "Subtotal"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '16px',
      color: 'var(--shawn-ink)'
    }
  }, "$", total.toLocaleString())), (() => {
    const {
      Button
    } = window.SHAWNDesignSystem_ef7ee7;
    return /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      fullWidth: true
    }, "Proceed to Checkout");
  })(), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      color: 'var(--text-tertiary)',
      textAlign: 'center',
      marginTop: '14px',
      letterSpacing: '0.04em'
    }
  }, "Complimentary shipping and returns."))));
}
function Footer({
  navigate
}) {
  const {
    Input,
    Button
  } = window.SHAWNDesignSystem_ef7ee7;
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--shawn-charcoal)',
      color: 'var(--text-on-inverse)',
      padding: '90px var(--gutter) 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr',
      gap: '60px',
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      paddingBottom: '60px',
      borderBottom: '1px solid var(--line-on-inverse)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-wordmark)',
      fontSize: '20px',
      letterSpacing: '0.4em',
      paddingLeft: '0.4em',
      marginBottom: '18px'
    }
  }, "SHAWN"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '13px',
      lineHeight: 1.7,
      color: 'var(--text-on-inverse-soft)',
      maxWidth: '320px'
    }
  }, "Join the list. First access to each new edit, and the worlds beyond apparel."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '12px',
      alignItems: 'flex-end',
      marginTop: '24px',
      maxWidth: '360px'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Email address",
    containerStyle: {
      flex: 1
    },
    style: {
      color: 'var(--shawn-ivory)',
      borderBottomColor: 'var(--line-on-inverse)'
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    style: {
      color: 'var(--shawn-ivory)',
      borderColor: 'var(--line-on-inverse)'
    }
  }, "Join"))), [['Shop', ['New Arrivals', 'Knitwear', 'Tailoring', 'Accessories']], ['House', ['Our Story', 'Sustainability', 'Stores', 'Contact']]].map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      color: 'var(--text-on-inverse-soft)',
      marginBottom: '20px'
    }
  }, h), items.map(it => /*#__PURE__*/React.createElement("div", {
    key: it,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '13.5px',
      color: 'var(--shawn-ivory)',
      marginBottom: '12px',
      cursor: 'pointer',
      opacity: 0.85
    }
  }, it))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingTop: '28px',
      maxWidth: 'var(--content-max)',
      margin: '0 auto',
      flexWrap: 'wrap',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      letterSpacing: '0.08em',
      color: 'var(--text-on-inverse-soft)'
    }
  }, "\xA9 2026 SHAWN. Made to be kept."), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--text-on-inverse-soft)'
    }
  }, "Curated modern living")));
}
function App() {
  const [route, setRoute] = useState('home');
  const [productId, setProductId] = useState(null);
  const [bag, setBag] = useState([]);
  const [bagOpen, setBagOpen] = useState(false);
  const scrollRef = useRef(null);
  const navigate = (to, id = null) => {
    setRoute(to);
    if (id) setProductId(id);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  };
  const addToBag = (p, size) => {
    setBag(b => [...b, {
      ...p,
      size
    }]);
    setBagOpen(true);
  };
  const removeItem = i => setBag(b => b.filter((_, idx) => idx !== i));
  useEffect(() => {
    if (window.lucide) window.lucide.createIcons({
      attrs: {
        'stroke-width': 1.5
      }
    });
  });
  const screens = {
    home: /*#__PURE__*/React.createElement(Home, {
      navigate: navigate,
      addToBag: addToBag
    }),
    collection: /*#__PURE__*/React.createElement(Collection, {
      navigate: navigate,
      addToBag: addToBag
    }),
    product: /*#__PURE__*/React.createElement(Product, {
      navigate: navigate,
      addToBag: addToBag,
      productId: productId
    }),
    about: /*#__PURE__*/React.createElement(About, {
      navigate: navigate
    })
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: scrollRef,
    style: {
      height: '100vh',
      overflowY: 'auto',
      background: 'var(--shawn-ivory)'
    }
  }, /*#__PURE__*/React.createElement(Header, {
    navigate: navigate,
    route: route,
    bagCount: bag.length,
    openBag: () => setBagOpen(true)
  }), /*#__PURE__*/React.createElement("main", null, screens[route]), /*#__PURE__*/React.createElement(Footer, {
    navigate: navigate
  }), /*#__PURE__*/React.createElement(CartDrawer, {
    open: bagOpen,
    items: bag,
    onClose: () => setBagOpen(false),
    removeItem: removeItem,
    navigate: navigate
  }));
}
const SHAWN_MARK = '<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2.6" style="width:100%;height:100%"><g transform="rotate(-16 50 50)"><path d="M50 7 C 80 31 80 69 50 93 C 20 69 20 31 50 7 Z"/><path d="M50 29 C 64 42 64 58 50 71 C 36 58 36 42 50 29 Z"/></g></svg>';
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Collection.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// SHAWN — Collection screen
function Collection({
  navigate,
  addToBag
}) {
  const {
    Eyebrow,
    Tag,
    ProductCard
  } = window.SHAWNDesignSystem_ef7ee7;
  const all = window.SHAWN_DATA.products;
  const filters = window.SHAWN_DATA.collections;
  const [active, setActive] = React.useState('All');
  const shown = active === 'All' ? all : all.filter(p => p.category === active);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '64px var(--gutter) 120px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: '48px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: '16px',
      display: 'block'
    }
  }, "SHAWN Apparel"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 'clamp(2.4rem, 4vw, 3.4rem)',
      margin: 0,
      color: 'var(--shawn-ink)'
    }
  }, "The Collection"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '13px',
      letterSpacing: '0.04em',
      color: 'var(--shawn-taupe)',
      marginTop: '14px'
    }
  }, shown.length, " pieces, made to be kept")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px',
      justifyContent: 'center',
      flexWrap: 'wrap',
      marginBottom: '54px',
      paddingBottom: '28px',
      borderBottom: '1px solid var(--line-hairline)'
    }
  }, filters.map(f => /*#__PURE__*/React.createElement("button", {
    key: f,
    onClick: () => setActive(f),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '10.5px',
      fontWeight: 500,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      cursor: 'pointer',
      padding: '8px 16px',
      borderRadius: 'var(--radius-pill)',
      border: `1px solid ${active === f ? 'var(--shawn-ink)' : 'var(--line-soft)'}`,
      background: active === f ? 'var(--shawn-ink)' : 'transparent',
      color: active === f ? 'var(--shawn-ivory)' : 'var(--text-secondary)',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, f))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: '28px 28px'
    }
  }, shown.map(p => /*#__PURE__*/React.createElement(ProductCard, _extends({
    key: p.id
  }, p, {
    imageColor: p.color,
    onClick: () => navigate('product', p.id)
  })))));
}
window.Collection = Collection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Collection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Home.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// SHAWN — Home screen
function Home({
  navigate,
  addToBag
}) {
  const {
    Eyebrow,
    Button,
    ProductCard
  } = window.SHAWNDesignSystem_ef7ee7;
  const products = window.SHAWN_DATA.products;
  const edit = products.slice(0, 4);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      background: 'var(--shawn-sand)',
      minHeight: '620px',
      display: 'flex',
      alignItems: 'flex-end',
      padding: '64px var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '640px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: "ink",
    style: {
      marginBottom: '22px',
      display: 'block'
    }
  }, "Autumn \xB7 The New Edit"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 'clamp(2.8rem, 5vw, 4.6rem)',
      lineHeight: 1.05,
      margin: 0,
      color: 'var(--shawn-ink)',
      letterSpacing: '0.01em'
    }
  }, "The considered", /*#__PURE__*/React.createElement("br", null), "wardrobe."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '17px',
      lineHeight: 1.6,
      color: 'var(--shawn-espresso)',
      maxWidth: '440px',
      margin: '24px 0 34px'
    }
  }, "A short edit of pieces made to be kept. No noise, no rush. Just good taste."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => navigate('collection')
  }, "Explore the Edit"))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '110px var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: '48px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: '14px',
      display: 'block'
    }
  }, "The Edit"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: '40px',
      margin: 0,
      color: 'var(--shawn-ink)'
    }
  }, "Made to be kept.")), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('collection'),
    style: ghostLink
  }, "View all \xA0\u2192")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: '28px'
    }
  }, edit.map(p => /*#__PURE__*/React.createElement(ProductCard, _extends({
    key: p.id
  }, p, {
    imageColor: p.color,
    onClick: () => navigate('product', p.id)
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      alignItems: 'stretch'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--shawn-stone)',
      minHeight: '520px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--shawn-bone)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      padding: '80px var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    style: {
      marginBottom: '20px',
      display: 'block'
    }
  }, "The House"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: '34px',
      lineHeight: 1.2,
      margin: '0 0 20px',
      color: 'var(--shawn-ink)'
    }
  }, "A carefully curated life, beginning with the wardrobe."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      lineHeight: 1.7,
      color: 'var(--shawn-espresso)',
      maxWidth: '420px',
      margin: '0 0 30px'
    }
  }, "SHAWN is a modern lifestyle house. We begin with apparel and grow into the everyday objects of a considered life. Quality over quantity. Design over trend."), /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('about'),
    style: ghostLink
  }, "Our story \xA0\u2192"))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--shawn-ink)',
      padding: '120px var(--gutter)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-editorial)',
      fontStyle: 'italic',
      fontSize: 'clamp(1.8rem, 3.4vw, 2.9rem)',
      lineHeight: 1.4,
      color: 'var(--shawn-ivory)',
      maxWidth: '880px',
      margin: '0 auto',
      fontWeight: 500
    }
  }, "Customers are not buying clothes. They are buying a carefully curated life.")));
}
const ghostLink = {
  fontFamily: 'var(--font-sans)',
  fontSize: '11.5px',
  fontWeight: 500,
  letterSpacing: '0.16em',
  textTransform: 'uppercase',
  color: 'var(--shawn-ink)',
  background: 'none',
  border: 'none',
  cursor: 'pointer',
  padding: '4px 0',
  whiteSpace: 'nowrap'
};
window.Home = Home;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Product.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// SHAWN — Product detail screen
function Product({
  navigate,
  addToBag,
  productId
}) {
  const {
    Eyebrow,
    Button,
    Tag
  } = window.SHAWNDesignSystem_ef7ee7;
  const data = window.SHAWN_DATA.products;
  const p = data.find(x => x.id === productId) || data[0];
  const sizes = ['XS', 'S', 'M', 'L', 'XL'];
  const [size, setSize] = React.useState('M');
  const [open, setOpen] = React.useState('details');
  const more = data.filter(x => x.id !== p.id).slice(0, 4);
  const accordion = [{
    key: 'details',
    label: 'Details',
    body: p.desc
  }, {
    key: 'fabric',
    label: 'Fabric & Care',
    body: 'Premium natural fibres. Dry clean only. Store folded, away from direct light. Made to last for many seasons.'
  }, {
    key: 'shipping',
    label: 'Shipping & Returns',
    body: 'Complimentary shipping within the region. Returns accepted within 30 days, unworn with tags.'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px var(--gutter) 110px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => navigate('collection'),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--shawn-taupe)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      marginBottom: '34px'
    }
  }, "\u2190 \xA0The Collection"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.15fr 1fr',
      gap: '64px',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: p.color,
      aspectRatio: '3 / 4',
      width: '100%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--shawn-bone)',
      aspectRatio: '1'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--shawn-stone)',
      aspectRatio: '1'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: p.color,
      aspectRatio: '1',
      opacity: 0.7
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: '110px'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: "muted",
    style: {
      marginBottom: '14px',
      display: 'block'
    }
  }, p.category), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: '40px',
      lineHeight: 1.1,
      margin: '0 0 12px',
      color: 'var(--shawn-ink)'
    }
  }, p.name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '18px',
      color: 'var(--shawn-espresso)',
      margin: '0 0 30px',
      letterSpacing: '0.02em'
    }
  }, p.price), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '15px',
      lineHeight: 1.7,
      color: 'var(--shawn-espresso)',
      margin: '0 0 34px',
      maxWidth: '420px'
    }
  }, p.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: '28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '10px',
      fontWeight: 500,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)',
      marginBottom: '12px'
    }
  }, "Size"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px'
    }
  }, sizes.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    onClick: () => setSize(s),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '12px',
      letterSpacing: '0.06em',
      cursor: 'pointer',
      width: '46px',
      height: '46px',
      borderRadius: 'var(--radius-md)',
      border: `1px solid ${size === s ? 'var(--shawn-ink)' : 'var(--line-soft)'}`,
      background: size === s ? 'var(--shawn-ink)' : 'transparent',
      color: size === s ? 'var(--shawn-ivory)' : 'var(--text-primary)',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, s)))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => addToBag(p, size),
    style: {
      marginBottom: '14px'
    }
  }, "Add to Bag"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    fullWidth: true
  }, "Book an Appointment"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '40px',
      borderTop: '1px solid var(--line-hairline)'
    }
  }, accordion.map(a => /*#__PURE__*/React.createElement("div", {
    key: a.key,
    style: {
      borderBottom: '1px solid var(--line-hairline)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(open === a.key ? '' : a.key),
    style: {
      width: '100%',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '20px 0',
      fontFamily: 'var(--font-sans)',
      fontSize: '11px',
      fontWeight: 500,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--shawn-ink)'
    }
  }, a.label, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '16px',
      color: 'var(--shawn-taupe)'
    }
  }, open === a.key ? '\u2212' : '+')), open === a.key && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '14px',
      lineHeight: 1.7,
      color: 'var(--shawn-espresso)',
      margin: '0 0 22px',
      maxWidth: '420px'
    }
  }, a.body)))))), /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: '120px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: '28px',
      margin: '0 0 40px',
      color: 'var(--shawn-ink)',
      textAlign: 'center'
    }
  }, "You may also like"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: '28px'
    }
  }, more.map(m => {
    const {
      ProductCard
    } = window.SHAWNDesignSystem_ef7ee7;
    return /*#__PURE__*/React.createElement(ProductCard, _extends({
      key: m.id
    }, m, {
      imageColor: m.color,
      onClick: () => navigate('product', m.id)
    }));
  }))));
}
window.Product = Product;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Product.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
// SHAWN Apparel — sample catalogue for the UI kit. Tonal placeholders, no photos.
window.SHAWN_DATA = {
  products: [{
    id: 'cashmere-crew',
    category: 'Knitwear',
    name: 'The Cashmere Crew',
    price: '$320',
    badge: 'New',
    color: 'var(--shawn-sand)',
    desc: 'A relaxed cashmere crew in stone. Cut for ease and made to last, this is the piece you reach for on the quiet days.'
  }, {
    id: 'wool-trouser',
    category: 'Tailoring',
    name: 'Relaxed Wool Trouser',
    price: '$280',
    color: 'var(--shawn-stone)',
    desc: 'A soft tailored trouser with a relaxed line. Wears with everything, holds its shape, made to be kept.'
  }, {
    id: 'long-coat',
    category: 'Outerwear',
    name: 'The Long Coat',
    price: '$640',
    badge: 'New',
    color: 'var(--shawn-taupe)',
    desc: 'A considered long coat in espresso wool. Unstructured, generous, and quietly luxurious.'
  }, {
    id: 'silk-shirt',
    category: 'Shirting',
    name: 'The Silk Shirt',
    price: '$240',
    color: 'var(--shawn-bone)',
    desc: 'A fluid silk shirt in ivory. An essential that moves between the day and the evening with ease.'
  }, {
    id: 'knit-dress',
    category: 'Dresses',
    name: 'The Column Dress',
    price: '$360',
    color: 'var(--shawn-clay-soft)',
    desc: 'A clean knit column in clay. Simple, elegant, and made to be kept for many seasons.'
  }, {
    id: 'leather-tote',
    category: 'Accessories',
    name: 'The Everyday Tote',
    price: '$420',
    color: 'var(--shawn-espresso)',
    desc: 'A soft leather tote in espresso. Roomy, understated, and built for a full modern day.'
  }, {
    id: 'wide-knit',
    category: 'Knitwear',
    name: 'The Wide Knit',
    price: '$300',
    color: 'var(--shawn-sand)',
    desc: 'An oversized rib knit in bone. Easy over everything, warm without weight.'
  }, {
    id: 'tailored-vest',
    category: 'Tailoring',
    name: 'The Tailored Vest',
    price: '$210',
    badge: 'New',
    color: 'var(--shawn-stone)',
    desc: 'A neat tailored vest in stone. Layered or alone, it sharpens the quietest outfit.'
  }],
  collections: ['All', 'Knitwear', 'Tailoring', 'Outerwear', 'Shirting', 'Accessories']
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.Tag = __ds_scope.Tag;

})();
