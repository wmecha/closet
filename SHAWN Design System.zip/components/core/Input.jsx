import React from 'react';

/** SHAWN Input — underline-only text field with a wide-tracked label. */
export function Input({ label, id, type = 'text', style, containerStyle, ...rest }) {
  const [focused, setFocused] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: '8px', ...containerStyle }}>
      {label && (
        <span style={{
          fontFamily: 'var(--font-sans)', fontSize: '10px', fontWeight: 500,
          letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase',
          color: 'var(--text-secondary)',
        }}>{label}</span>
      )}
      <input
        id={id}
        type={type}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body)',
          color: 'var(--text-primary)',
          background: 'transparent',
          border: 'none',
          borderBottom: `1px solid ${focused ? 'var(--shawn-ink)' : 'var(--line-soft)'}`,
          padding: '8px 0',
          outline: 'none',
          transition: 'border-color var(--dur-fast) var(--ease-standard)',
          ...style,
        }}
        {...rest}
      />
    </label>
  );
}
