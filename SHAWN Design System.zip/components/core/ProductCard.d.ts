import React from 'react';

/**
 * Image-first editorial product tile with a slow hover zoom.
 * @startingPoint section="Commerce" subtitle="Editorial product tile" viewport="320x460"
 */
export interface ProductCardProps extends React.HTMLAttributes<HTMLDivElement> {
  name: string;
  price: string;
  category?: string;
  /** Small overlay label, e.g. "New". */
  badge?: string;
  /** Image URL. If omitted, a tonal placeholder shows. */
  image?: string;
  /** Placeholder fill colour when no image. */
  imageColor?: string;
  onClick?: () => void;
}

/**
 * Image-first editorial product tile with a slow hover zoom.
 */
export function ProductCard(props: ProductCardProps): JSX.Element;
