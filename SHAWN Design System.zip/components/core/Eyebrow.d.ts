import React from 'react';

export interface EyebrowProps extends React.HTMLAttributes<HTMLElement> {
  /** Colour role or any CSS colour. Default accent (clay). */
  color?: 'accent' | 'muted' | 'ink' | 'light' | string;
  as?: keyof JSX.IntrinsicElements;
  children?: React.ReactNode;
}

/** Wide-tracked uppercase label that sits above a serif headline. */
export function Eyebrow(props: EyebrowProps): JSX.Element;
