import React from 'react';

/** SHAWN Tag — small uppercase chip for status, category, or filter. */
export function Tag({ children, variant = 'outline', style, ...rest }) {
  const variants = {
    outline: { background: 'transparent', color: 'var(--text-secondary)', border: '1px solid var(--line-soft)' },
    solid: { background: 'var(--shawn-ink)', color: 'var(--shawn-ivory)', border: '1px solid var(--shawn-ink)' },
    accent: { background: 'transparent', color: 'var(--shawn-clay)', border: '1px solid var(--shawn-clay)' },
    bare: { background: 'transparent', color: 'var(--text-secondary)', border: '1px solid transparent', padding: '4px 0' },
  };
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        fontFamily: 'var(--font-sans)',
        fontSize: '10px',
        fontWeight: 500,
        letterSpacing: 'var(--tracking-label)',
        textTransform: 'uppercase',
        padding: '5px 11px',
        borderRadius: 'var(--radius-pill)',
        lineHeight: 1,
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
