import React from 'react';

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** outline (default), solid, accent, or bare (no chrome). */
  variant?: 'outline' | 'solid' | 'accent' | 'bare';
  children?: React.ReactNode;
}

/** Small uppercase chip for category, status, or filter. */
export function Tag(props: TagProps): JSX.Element;
