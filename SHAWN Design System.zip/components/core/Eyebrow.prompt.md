The wide-tracked uppercase label that introduces a section, always paired above a serif headline. A signature SHAWN device.

```jsx
<Eyebrow>The Edit</Eyebrow>
<h2>Made to be kept.</h2>
```

Colours: `accent` (clay, default), `muted` (taupe), `ink`, `light` (for dark surfaces). Keep the text short, two or three words.
