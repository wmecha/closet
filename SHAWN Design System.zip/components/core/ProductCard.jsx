import React from 'react';

/** SHAWN ProductCard — image-first editorial product tile with slow hover zoom. */
export function ProductCard({ name, price, category, badge, image, imageColor = 'var(--shawn-sand)', onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ cursor: onClick ? 'pointer' : 'default', fontFamily: 'var(--font-sans)', ...style }}
      {...rest}
    >
      <div style={{ position: 'relative', overflow: 'hidden', background: imageColor, aspectRatio: '3 / 4' }}>
        {image && (
          <img src={image} alt={name} style={{
            width: '100%', height: '100%', objectFit: 'cover', display: 'block',
            transform: hover ? 'scale(1.04)' : 'scale(1)',
            transition: 'transform var(--dur-slow) var(--ease-standard)',
          }} />
        )}
        {badge && (
          <span style={{
            position: 'absolute', top: '14px', left: '14px',
            fontSize: '9.5px', fontWeight: 500, letterSpacing: 'var(--tracking-label)',
            textTransform: 'uppercase', color: 'var(--shawn-ink)',
            background: 'var(--shawn-ivory)', padding: '5px 10px',
          }}>{badge}</span>
        )}
      </div>
      <div style={{ paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '5px' }}>
        {category && (
          <span style={{ fontSize: '10px', letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: 'var(--text-tertiary)' }}>{category}</span>
        )}
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--fs-title)', color: 'var(--text-primary)', lineHeight: 1.2 }}>{name}</span>
        <span style={{ fontSize: 'var(--fs-body)', color: 'var(--text-secondary)', letterSpacing: '0.02em' }}>{price}</span>
      </div>
    </div>
  );
}
