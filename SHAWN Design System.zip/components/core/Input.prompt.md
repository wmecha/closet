A minimal, underline-only text field. Used in checkout, newsletter sign-up, and account forms.

```jsx
<Input label="Email" type="email" placeholder="you@example.com" />
```

No box, no fill. The underline darkens to ink on focus. Pair the label in wide-tracked uppercase.
