import React from 'react';

/**
 * SHAWN primary call to action. Quiet, uppercase, wide tracking.
 * @startingPoint section="Core" subtitle="Editorial CTA button" viewport="320x120"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. primary = ink fill, secondary = outline, ghost = underlined link. */
  variant?: 'primary' | 'secondary' | 'ghost';
  /** Size. Default md. */
  size?: 'sm' | 'md' | 'lg';
  /** Stretch to container width. */
  fullWidth?: boolean;
  disabled?: boolean;
  /** Render as a different element, e.g. 'a' for links. */
  as?: 'button' | 'a';
  children?: React.ReactNode;
}

/**
 * SHAWN primary call to action. Quiet, uppercase, wide tracking.
 */
export function Button(props: ButtonProps): JSX.Element;
