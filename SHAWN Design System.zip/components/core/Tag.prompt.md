A small uppercase chip for category, new-arrival status, or a filter pill.

```jsx
<Tag variant="accent">New</Tag>
<Tag variant="outline">Knitwear</Tag>
<Tag variant="solid">The Edit</Tag>
```

Variants: `outline` (default), `solid` (ink), `accent` (clay), `bare` (label only). Keep labels to one or two words.
