import React from 'react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Wide-tracked uppercase label shown above the field. */
  label?: string;
  containerStyle?: React.CSSProperties;
}

/** Minimal underline-only text input. */
export function Input(props: InputProps): JSX.Element;
