The SHAWN call to action. Use for primary actions like Add to Bag and Explore the Edit. Quiet and uppercase, never loud.

```jsx
<Button variant="primary">Add to Bag</Button>
<Button variant="secondary">Book an Appointment</Button>
<Button variant="ghost">View the Edit</Button>
```

Variants: `primary` (ink fill, hovers to espresso), `secondary` (hairline outline), `ghost` (underlined text link). Sizes `sm` / `md` / `lg`. Use `fullWidth` in product side panels. Pass `as="a"` with `href` for navigation. Never use more than one primary button in a view.
