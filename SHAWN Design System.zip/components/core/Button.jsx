import React from 'react';

/**
 * SHAWN Button — quiet, editorial, uppercase with wide tracking.
 * Variants: primary (ink fill), secondary (outline), ghost (underlined link).
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  as = 'button',
  style,
  ...rest
}) {
  const pad = size === 'sm' ? '10px 20px' : size === 'lg' ? '18px 40px' : '14px 30px';
  const fs = size === 'sm' ? '10.5px' : '11.5px';

  const base = {
    fontFamily: 'var(--font-sans)',
    fontSize: fs,
    fontWeight: 500,
    letterSpacing: '0.16em',
    textTransform: 'uppercase',
    padding: pad,
    borderRadius: 'var(--radius-md)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    width: fullWidth ? '100%' : 'auto',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '10px',
    transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard), opacity var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)',
    opacity: disabled ? 0.4 : 1,
    textDecoration: 'none',
    lineHeight: 1,
  };

  const variants = {
    primary: { background: 'var(--shawn-ink)', color: 'var(--shawn-ivory)', border: '1px solid var(--shawn-ink)' },
    secondary: { background: 'transparent', color: 'var(--shawn-ink)', border: '1px solid var(--line-strong)' },
    ghost: { background: 'transparent', color: 'var(--shawn-ink)', border: '1px solid transparent', padding: size === 'sm' ? '6px 2px' : '8px 2px', borderRadius: 0 },
  };

  const onEnter = (e) => {
    if (disabled) return;
    if (variant === 'primary') e.currentTarget.style.background = 'var(--shawn-espresso)';
    if (variant === 'secondary') e.currentTarget.style.borderColor = 'var(--shawn-ink)';
    if (variant === 'ghost') { e.currentTarget.style.opacity = '0.6'; e.currentTarget.style.boxShadow = 'inset 0 -1px 0 var(--shawn-ink)'; }
  };
  const onLeave = (e) => {
    if (disabled) return;
    if (variant === 'primary') e.currentTarget.style.background = 'var(--shawn-ink)';
    if (variant === 'secondary') e.currentTarget.style.borderColor = 'var(--line-strong)';
    if (variant === 'ghost') { e.currentTarget.style.opacity = '1'; e.currentTarget.style.boxShadow = 'none'; }
  };

  const Tag = as;
  return (
    <Tag
      style={{ ...base, ...variants[variant], ...style }}
      disabled={as === 'button' ? disabled : undefined}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
      {...rest}
    >
      {children}
    </Tag>
  );
}
