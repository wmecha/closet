import React from 'react';

/** SHAWN Eyebrow — small wide-tracked uppercase label above headings. */
export function Eyebrow({ children, color = 'accent', as = 'div', style, ...rest }) {
  const colors = {
    accent: 'var(--shawn-clay)',
    muted: 'var(--shawn-taupe)',
    ink: 'var(--shawn-ink)',
    light: 'var(--text-on-inverse-soft)',
  };
  const Tag = as;
  return (
    <Tag
      style={{
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-micro)',
        fontWeight: 500,
        letterSpacing: 'var(--tracking-eyebrow)',
        textTransform: 'uppercase',
        color: colors[color] || color,
        ...style,
      }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
