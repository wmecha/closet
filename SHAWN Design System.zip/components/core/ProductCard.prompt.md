The editorial product tile used across collection grids and the homepage edit. Image first, serif name, quiet price. The image zooms slowly on hover.

```jsx
<ProductCard
  category="Knitwear"
  name="The Cashmere Crew"
  price="$320"
  badge="New"
  image="/assets/look-01.jpg"
/>
```

A 3:4 image ratio. Use `imageColor` for a tonal placeholder when no photo is set. Keep names in serif, two to four words.
