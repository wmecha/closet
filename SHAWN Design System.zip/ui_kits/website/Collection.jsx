// SHAWN — Collection screen
function Collection({ navigate, addToBag }) {
  const { Eyebrow, Tag, ProductCard } = window.SHAWNDesignSystem_ef7ee7;
  const all = window.SHAWN_DATA.products;
  const filters = window.SHAWN_DATA.collections;
  const [active, setActive] = React.useState('All');
  const shown = active === 'All' ? all : all.filter(p => p.category === active);

  return (
    <div style={{ padding: '64px var(--gutter) 120px' }}>
      <div style={{ textAlign: 'center', marginBottom: '48px' }}>
        <Eyebrow style={{ marginBottom: '16px', display: 'block' }}>SHAWN Apparel</Eyebrow>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: 'clamp(2.4rem, 4vw, 3.4rem)', margin: 0, color: 'var(--shawn-ink)' }}>The Collection</h1>
        <p style={{ fontFamily: 'var(--font-sans)', fontSize: '13px', letterSpacing: '0.04em', color: 'var(--shawn-taupe)', marginTop: '14px' }}>
          {shown.length} pieces, made to be kept
        </p>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '54px', paddingBottom: '28px', borderBottom: '1px solid var(--line-hairline)' }}>
        {filters.map(f => (
          <button key={f} onClick={() => setActive(f)} style={{
            fontFamily: 'var(--font-sans)', fontSize: '10.5px', fontWeight: 500, letterSpacing: '0.16em',
            textTransform: 'uppercase', cursor: 'pointer', padding: '8px 16px', borderRadius: 'var(--radius-pill)',
            border: `1px solid ${active === f ? 'var(--shawn-ink)' : 'var(--line-soft)'}`,
            background: active === f ? 'var(--shawn-ink)' : 'transparent',
            color: active === f ? 'var(--shawn-ivory)' : 'var(--text-secondary)',
            transition: 'all var(--dur-fast) var(--ease-standard)',
          }}>{f}</button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '28px 28px' }}>
        {shown.map(p => (
          <ProductCard key={p.id} {...p} imageColor={p.color} onClick={() => navigate('product', p.id)} />
        ))}
      </div>
    </div>
  );
}

window.Collection = Collection;
