# SHAWN Apparel — Website UI Kit

An interactive, editorial e-commerce recreation of the SHAWN storefront. This is the reference for the website direction: premium, minimal, editorial, conversion-focused.

## Run
Open `index.html`. It loads React, the compiled design-system bundle (`_ds_bundle.js`), Lucide icons, and the screen files.

## Screens
- `Home.jsx` — full-bleed hero, "The Edit" product grid, editorial split, quote band.
- `Collection.jsx` — filterable collection grid with category pills.
- `Product.jsx` — gallery, size selector, add to bag, detail accordion, related edit.
- `About.jsx` — brand statement, story, pillars, architecture wall.
- `App.jsx` — shell: sticky header with bag count, slide-in cart drawer, footer with newsletter, client-side routing.
- `data.js` — sample catalogue (`window.SHAWN_DATA`). Tonal placeholders stand in for photography.

## Interactions
- Navigate via the header (Shop, About) and the wordmark (Home).
- Click any product to open its detail page.
- Pick a size, Add to Bag. The cart drawer slides in; adjust quantity by removing items; subtotal updates.

## Composition
Screens compose the design-system primitives from `window.SHAWNDesignSystem_ef7ee7` (`Button`, `Eyebrow`, `Tag`, `Input`, `ProductCard`). Icons are Lucide at 1.5 stroke. Imagery is represented by warm tonal blocks; drop real photography into `ProductCard` via the `image` prop and into hero/section blocks.
