// SHAWN Apparel — sample catalogue for the UI kit. Tonal placeholders, no photos.
window.SHAWN_DATA = {
  products: [
    { id: 'cashmere-crew', category: 'Knitwear', name: 'The Cashmere Crew', price: '$320', badge: 'New', color: 'var(--shawn-sand)',
      desc: 'A relaxed cashmere crew in stone. Cut for ease and made to last, this is the piece you reach for on the quiet days.' },
    { id: 'wool-trouser', category: 'Tailoring', name: 'Relaxed Wool Trouser', price: '$280', color: 'var(--shawn-stone)',
      desc: 'A soft tailored trouser with a relaxed line. Wears with everything, holds its shape, made to be kept.' },
    { id: 'long-coat', category: 'Outerwear', name: 'The Long Coat', price: '$640', badge: 'New', color: 'var(--shawn-taupe)',
      desc: 'A considered long coat in espresso wool. Unstructured, generous, and quietly luxurious.' },
    { id: 'silk-shirt', category: 'Shirting', name: 'The Silk Shirt', price: '$240', color: 'var(--shawn-bone)',
      desc: 'A fluid silk shirt in ivory. An essential that moves between the day and the evening with ease.' },
    { id: 'knit-dress', category: 'Dresses', name: 'The Column Dress', price: '$360', color: 'var(--shawn-clay-soft)',
      desc: 'A clean knit column in clay. Simple, elegant, and made to be kept for many seasons.' },
    { id: 'leather-tote', category: 'Accessories', name: 'The Everyday Tote', price: '$420', color: 'var(--shawn-espresso)',
      desc: 'A soft leather tote in espresso. Roomy, understated, and built for a full modern day.' },
    { id: 'wide-knit', category: 'Knitwear', name: 'The Wide Knit', price: '$300', color: 'var(--shawn-sand)',
      desc: 'An oversized rib knit in bone. Easy over everything, warm without weight.' },
    { id: 'tailored-vest', category: 'Tailoring', name: 'The Tailored Vest', price: '$210', badge: 'New', color: 'var(--shawn-stone)',
      desc: 'A neat tailored vest in stone. Layered or alone, it sharpens the quietest outfit.' },
  ],
  collections: ['All', 'Knitwear', 'Tailoring', 'Outerwear', 'Shirting', 'Accessories'],
};
