// SHAWN — Home screen
function Home({ navigate, addToBag }) {
  const { Eyebrow, Button, ProductCard } = window.SHAWNDesignSystem_ef7ee7;
  const products = window.SHAWN_DATA.products;
  const edit = products.slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section style={{ position: 'relative', background: 'var(--shawn-sand)', minHeight: '620px', display: 'flex', alignItems: 'flex-end', padding: '64px var(--gutter)' }}>
        <div style={{ maxWidth: '640px' }}>
          <Eyebrow color="ink" style={{ marginBottom: '22px', display: 'block' }}>Autumn · The New Edit</Eyebrow>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: 'clamp(2.8rem, 5vw, 4.6rem)', lineHeight: 1.05, margin: 0, color: 'var(--shawn-ink)', letterSpacing: '0.01em' }}>
            The considered<br />wardrobe.
          </h1>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '17px', lineHeight: 1.6, color: 'var(--shawn-espresso)', maxWidth: '440px', margin: '24px 0 34px' }}>
            A short edit of pieces made to be kept. No noise, no rush. Just good taste.
          </p>
          <Button variant="primary" onClick={() => navigate('collection')}>Explore the Edit</Button>
        </div>
      </section>

      {/* The Edit grid */}
      <section style={{ padding: '110px var(--gutter)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: '48px' }}>
          <div>
            <Eyebrow style={{ marginBottom: '14px', display: 'block' }}>The Edit</Eyebrow>
            <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: '40px', margin: 0, color: 'var(--shawn-ink)' }}>Made to be kept.</h2>
          </div>
          <button onClick={() => navigate('collection')} style={ghostLink}>View all &nbsp;&rarr;</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '28px' }}>
          {edit.map(p => (
            <ProductCard key={p.id} {...p} imageColor={p.color} onClick={() => navigate('product', p.id)} />
          ))}
        </div>
      </section>

      {/* Editorial split */}
      <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', alignItems: 'stretch' }}>
        <div style={{ background: 'var(--shawn-stone)', minHeight: '520px' }}></div>
        <div style={{ background: 'var(--shawn-bone)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '80px var(--gutter)' }}>
          <Eyebrow style={{ marginBottom: '20px', display: 'block' }}>The House</Eyebrow>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: '34px', lineHeight: 1.2, margin: '0 0 20px', color: 'var(--shawn-ink)' }}>
            A carefully curated life, beginning with the wardrobe.
          </h2>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '15px', lineHeight: 1.7, color: 'var(--shawn-espresso)', maxWidth: '420px', margin: '0 0 30px' }}>
            SHAWN is a modern lifestyle house. We begin with apparel and grow into the everyday objects of a considered life. Quality over quantity. Design over trend.
          </p>
          <button onClick={() => navigate('about')} style={ghostLink}>Our story &nbsp;&rarr;</button>
        </div>
      </section>

      {/* Quote band */}
      <section style={{ background: 'var(--shawn-ink)', padding: '120px var(--gutter)', textAlign: 'center' }}>
        <p style={{ fontFamily: 'var(--font-editorial)', fontStyle: 'italic', fontSize: 'clamp(1.8rem, 3.4vw, 2.9rem)', lineHeight: 1.4, color: 'var(--shawn-ivory)', maxWidth: '880px', margin: '0 auto', fontWeight: 500 }}>
            Customers are not buying clothes. They are buying a carefully curated life.
        </p>
      </section>
    </div>
  );
}

const ghostLink = {
  fontFamily: 'var(--font-sans)', fontSize: '11.5px', fontWeight: 500, letterSpacing: '0.16em',
  textTransform: 'uppercase', color: 'var(--shawn-ink)', background: 'none', border: 'none',
  cursor: 'pointer', padding: '4px 0', whiteSpace: 'nowrap',
};

window.Home = Home;
