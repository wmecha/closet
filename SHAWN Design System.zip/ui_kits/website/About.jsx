// SHAWN — About screen
function About({ navigate }) {
  const { Eyebrow, Button } = window.SHAWNDesignSystem_ef7ee7;
  const pillars = [
    { t: 'Confidence', d: 'Quiet, never loud. We let the work speak.' },
    { t: 'Taste', d: 'A discerning point of view. We edit so you do not have to.' },
    { t: 'Curation', d: 'A tightly chosen collection beats an endless catalogue.' },
    { t: 'Modern living', d: 'Designed for a full, mobile, considered life.' },
  ];
  const divisions = ['Apparel', 'Beauty', 'Home', 'Living', 'Studio'];

  return (
    <div>
      {/* Statement hero */}
      <section style={{ padding: '120px var(--gutter)', textAlign: 'center', background: 'var(--shawn-bone)' }}>
        <Eyebrow style={{ marginBottom: '26px', display: 'block' }}>The House of SHAWN</Eyebrow>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: 'clamp(2.4rem, 4.4vw, 4rem)', lineHeight: 1.15, margin: '0 auto', maxWidth: '880px', color: 'var(--shawn-ink)' }}>
          A modern lifestyle house, beginning with fashion.
        </h1>
      </section>

      {/* Narrative */}
      <section style={{ padding: '110px var(--gutter)', display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: '80px', alignItems: 'center', maxWidth: 'var(--content-max)', margin: '0 auto' }}>
        <div style={{ background: 'var(--shawn-stone)', aspectRatio: '4 / 5' }}></div>
        <div>
          <Eyebrow style={{ marginBottom: '20px', display: 'block' }}>Our Story</Eyebrow>
          <p style={{ fontFamily: 'var(--font-editorial)', fontStyle: 'italic', fontSize: '26px', lineHeight: 1.45, color: 'var(--shawn-espresso)', margin: '0 0 26px', fontWeight: 500 }}>
            SHAWN is built on a simple belief. That a life well lived is a curated one.
          </p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '15px', lineHeight: 1.75, color: 'var(--shawn-espresso)', margin: '0 0 18px', maxWidth: '480px' }}>
            We begin with apparel, a short edit of pieces made to be kept. From there we grow into the everyday objects of a considered life. Beauty, home, and the spaces in between.
          </p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '15px', lineHeight: 1.75, color: 'var(--shawn-espresso)', margin: 0, maxWidth: '480px' }}>
            Our ambition is international, our roots are proudly African, and our standard is timeless.
          </p>
        </div>
      </section>

      {/* Pillars */}
      <section style={{ padding: '0 var(--gutter) 110px', maxWidth: 'var(--content-max)', margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0', borderTop: '1px solid var(--line-soft)' }}>
          {pillars.map((p, i) => (
            <div key={p.t} style={{ padding: '34px 28px 34px 0', borderRight: i < 3 ? '1px solid var(--line-hairline)' : 'none', paddingLeft: i > 0 ? '28px' : 0 }}>
              <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: '22px', margin: '0 0 12px', color: 'var(--shawn-ink)' }}>{p.t}</h3>
              <p style={{ fontFamily: 'var(--font-sans)', fontSize: '13.5px', lineHeight: 1.65, color: 'var(--shawn-taupe)', margin: 0 }}>{p.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Architecture */}
      <section style={{ background: 'var(--shawn-ink)', padding: '110px var(--gutter)', textAlign: 'center' }}>
        <Eyebrow color="light" style={{ marginBottom: '40px', display: 'block' }}>One House, Many Worlds</Eyebrow>
        <div style={{ display: 'flex', gap: '0', justifyContent: 'center', flexWrap: 'wrap', maxWidth: '900px', margin: '0 auto' }}>
          {divisions.map((d, i) => (
            <div key={d} style={{ fontFamily: 'var(--font-wordmark)', letterSpacing: '0.2em', fontSize: '16px', color: i === 0 ? 'var(--shawn-ivory)' : 'var(--text-on-inverse-soft)', padding: '0 26px', borderRight: i < divisions.length - 1 ? '1px solid var(--line-on-inverse)' : 'none', opacity: i === 0 ? 1 : 0.7 }}>
              SHAWN<br /><span style={{ fontSize: '11px', letterSpacing: '0.24em' }}>{d.toUpperCase()}</span>
            </div>
          ))}
        </div>
        <p style={{ fontFamily: 'var(--font-sans)', fontSize: '12px', letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--text-on-inverse-soft)', marginTop: '44px' }}>Apparel is live. The rest is coming.</p>
      </section>
    </div>
  );
}

window.About = About;
