// SHAWN — App shell: header, cart drawer, footer, routing
const { useState, useEffect, useRef } = React;

function Icon({ name, size = 19 }) {
  return <i data-lucide={name} style={{ width: size, height: size, display: 'inline-flex' }}></i>;
}

function Header({ navigate, route, bagCount, openBag }) {
  const link = (label, to) => (
    <button onClick={() => navigate(to)} style={{
      fontFamily: 'var(--font-sans)', fontSize: '11px', fontWeight: 500, letterSpacing: '0.16em',
      textTransform: 'uppercase', background: 'none', border: 'none', cursor: 'pointer',
      color: route === to ? 'var(--shawn-ink)' : 'var(--text-secondary)', padding: '4px 0',
      transition: 'color var(--dur-fast) var(--ease-standard)',
    }}
    onMouseEnter={e => e.currentTarget.style.color = 'var(--shawn-ink)'}
    onMouseLeave={e => e.currentTarget.style.color = route === to ? 'var(--shawn-ink)' : 'var(--text-secondary)'}>
      {label}
    </button>
  );

  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50, background: 'rgba(247,242,233,0.86)',
      backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--line-hairline)',
      display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center',
      padding: '20px var(--gutter)',
    }}>
      <nav style={{ display: 'flex', gap: '30px' }}>
        {link('Shop', 'collection')}
        {link('About', 'about')}
      </nav>
      <button onClick={() => navigate('home')} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '7px' }}>
        <span style={{ width: '26px', height: '26px', color: 'var(--shawn-ink)' }} dangerouslySetInnerHTML={{ __html: SHAWN_MARK }}></span>
        <span style={{ fontFamily: 'var(--font-wordmark)', fontSize: '17px', letterSpacing: '0.4em', paddingLeft: '0.4em', color: 'var(--shawn-ink)', lineHeight: 1 }}>SHAWN</span>
      </button>
      <div style={{ display: 'flex', gap: '22px', justifyContent: 'flex-end', alignItems: 'center', color: 'var(--shawn-ink)' }}>
        <button style={iconBtn} aria-label="Search"><Icon name="search" /></button>
        <button style={iconBtn} aria-label="Account"><Icon name="user" /></button>
        <button style={{ ...iconBtn, position: 'relative' }} aria-label="Bag" onClick={openBag}>
          <Icon name="shopping-bag" />
          {bagCount > 0 && (
            <span style={{ position: 'absolute', top: '-6px', right: '-8px', background: 'var(--shawn-clay)', color: 'var(--shawn-ivory)', fontFamily: 'var(--font-sans)', fontSize: '9px', fontWeight: 500, minWidth: '15px', height: '15px', borderRadius: '999px', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px' }}>{bagCount}</span>
          )}
        </button>
      </div>
    </header>
  );
}

const iconBtn = { background: 'none', border: 'none', cursor: 'pointer', color: 'inherit', padding: 0, display: 'inline-flex' };

function CartDrawer({ open, items, onClose, removeItem, navigate }) {
  const total = items.reduce((s, it) => s + parseFloat(it.price.replace(/[^0-9.]/g, '')), 0);
  return (
    <>
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, background: 'rgba(26,23,20,0.36)', zIndex: 60,
        opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none',
        transition: 'opacity var(--dur-base) var(--ease-standard)',
      }}></div>
      <aside style={{
        position: 'fixed', top: 0, right: 0, bottom: 0, width: '420px', maxWidth: '90vw', zIndex: 61,
        background: 'var(--shawn-ivory)', boxShadow: 'var(--shadow-lg)',
        transform: open ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform var(--dur-base) var(--ease-entrance)',
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '26px 30px', borderBottom: '1px solid var(--line-hairline)' }}>
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: '11px', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--shawn-ink)' }}>Your Bag · {items.length}</span>
          <button onClick={onClose} style={{ ...iconBtn, color: 'var(--shawn-ink)' }} aria-label="Close"><Icon name="x" /></button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 30px' }}>
          {items.length === 0 ? (
            <p style={{ fontFamily: 'var(--font-sans)', fontSize: '14px', color: 'var(--text-secondary)', textAlign: 'center', marginTop: '60px', lineHeight: 1.7 }}>
              Your bag is quiet for now.<br />The edit is waiting.
            </p>
          ) : items.map((it, i) => (
            <div key={i} style={{ display: 'flex', gap: '16px', padding: '20px 0', borderBottom: '1px solid var(--line-hairline)' }}>
              <div style={{ width: '68px', height: '88px', background: it.color, flex: 'none' }}></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '16px', color: 'var(--shawn-ink)', marginBottom: '4px' }}>{it.name}</div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: '11px', letterSpacing: '0.06em', color: 'var(--text-secondary)', marginBottom: '10px' }}>Size {it.size}</div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: '14px', color: 'var(--shawn-espresso)' }}>{it.price}</div>
              </div>
              <button onClick={() => removeItem(i)} style={{ fontFamily: 'var(--font-sans)', fontSize: '10px', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--text-tertiary)', background: 'none', border: 'none', cursor: 'pointer', alignSelf: 'flex-start' }}>Remove</button>
            </div>
          ))}
        </div>

        {items.length > 0 && (
          <div style={{ padding: '24px 30px 30px', borderTop: '1px solid var(--line-soft)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '18px', fontFamily: 'var(--font-sans)' }}>
              <span style={{ fontSize: '11px', letterSpacing: '0.16em', textTransform: 'uppercase', color: 'var(--text-secondary)' }}>Subtotal</span>
              <span style={{ fontSize: '16px', color: 'var(--shawn-ink)' }}>${total.toLocaleString()}</span>
            </div>
            {(() => { const { Button } = window.SHAWNDesignSystem_ef7ee7; return <Button variant="primary" fullWidth>Proceed to Checkout</Button>; })()}
            <p style={{ fontFamily: 'var(--font-sans)', fontSize: '11px', color: 'var(--text-tertiary)', textAlign: 'center', marginTop: '14px', letterSpacing: '0.04em' }}>Complimentary shipping and returns.</p>
          </div>
        )}
      </aside>
    </>
  );
}

function Footer({ navigate }) {
  const { Input, Button } = window.SHAWNDesignSystem_ef7ee7;
  return (
    <footer style={{ background: 'var(--shawn-charcoal)', color: 'var(--text-on-inverse)', padding: '90px var(--gutter) 40px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: '60px', maxWidth: 'var(--content-max)', margin: '0 auto', paddingBottom: '60px', borderBottom: '1px solid var(--line-on-inverse)' }}>
        <div>
          <div style={{ fontFamily: 'var(--font-wordmark)', fontSize: '20px', letterSpacing: '0.4em', paddingLeft: '0.4em', marginBottom: '18px' }}>SHAWN</div>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '13px', lineHeight: 1.7, color: 'var(--text-on-inverse-soft)', maxWidth: '320px' }}>
            Join the list. First access to each new edit, and the worlds beyond apparel.
          </p>
          <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-end', marginTop: '24px', maxWidth: '360px' }}>
            <Input placeholder="Email address" containerStyle={{ flex: 1 }} style={{ color: 'var(--shawn-ivory)', borderBottomColor: 'var(--line-on-inverse)' }} />
            <Button variant="secondary" size="sm" style={{ color: 'var(--shawn-ivory)', borderColor: 'var(--line-on-inverse)' }}>Join</Button>
          </div>
        </div>
        {[['Shop', ['New Arrivals', 'Knitwear', 'Tailoring', 'Accessories']], ['House', ['Our Story', 'Sustainability', 'Stores', 'Contact']]].map(([h, items]) => (
          <div key={h}>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--text-on-inverse-soft)', marginBottom: '20px' }}>{h}</div>
            {items.map(it => (
              <div key={it} style={{ fontFamily: 'var(--font-sans)', fontSize: '13.5px', color: 'var(--shawn-ivory)', marginBottom: '12px', cursor: 'pointer', opacity: 0.85 }}>{it}</div>
            ))}
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '28px', maxWidth: 'var(--content-max)', margin: '0 auto', flexWrap: 'wrap', gap: '12px' }}>
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: '11px', letterSpacing: '0.08em', color: 'var(--text-on-inverse-soft)' }}>&copy; 2026 SHAWN. Made to be kept.</span>
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--text-on-inverse-soft)' }}>Curated modern living</span>
      </div>
    </footer>
  );
}

function App() {
  const [route, setRoute] = useState('home');
  const [productId, setProductId] = useState(null);
  const [bag, setBag] = useState([]);
  const [bagOpen, setBagOpen] = useState(false);
  const scrollRef = useRef(null);

  const navigate = (to, id = null) => {
    setRoute(to);
    if (id) setProductId(id);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  };
  const addToBag = (p, size) => { setBag(b => [...b, { ...p, size }]); setBagOpen(true); };
  const removeItem = (i) => setBag(b => b.filter((_, idx) => idx !== i));

  useEffect(() => { if (window.lucide) window.lucide.createIcons({ attrs: { 'stroke-width': 1.5 } }); });

  const screens = {
    home: <Home navigate={navigate} addToBag={addToBag} />,
    collection: <Collection navigate={navigate} addToBag={addToBag} />,
    product: <Product navigate={navigate} addToBag={addToBag} productId={productId} />,
    about: <About navigate={navigate} />,
  };

  return (
    <div ref={scrollRef} style={{ height: '100vh', overflowY: 'auto', background: 'var(--shawn-ivory)' }}>
      <Header navigate={navigate} route={route} bagCount={bag.length} openBag={() => setBagOpen(true)} />
      <main>{screens[route]}</main>
      <Footer navigate={navigate} />
      <CartDrawer open={bagOpen} items={bag} onClose={() => setBagOpen(false)} removeItem={removeItem} navigate={navigate} />
    </div>
  );
}

const SHAWN_MARK = '<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2.6" style="width:100%;height:100%"><g transform="rotate(-16 50 50)"><path d="M50 7 C 80 31 80 69 50 93 C 20 69 20 31 50 7 Z"/><path d="M50 29 C 64 42 64 58 50 71 C 36 58 36 42 50 29 Z"/></g></svg>';

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
