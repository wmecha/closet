// SHAWN — Product detail screen
function Product({ navigate, addToBag, productId }) {
  const { Eyebrow, Button, Tag } = window.SHAWNDesignSystem_ef7ee7;
  const data = window.SHAWN_DATA.products;
  const p = data.find(x => x.id === productId) || data[0];
  const sizes = ['XS', 'S', 'M', 'L', 'XL'];
  const [size, setSize] = React.useState('M');
  const [open, setOpen] = React.useState('details');
  const more = data.filter(x => x.id !== p.id).slice(0, 4);

  const accordion = [
    { key: 'details', label: 'Details', body: p.desc },
    { key: 'fabric', label: 'Fabric & Care', body: 'Premium natural fibres. Dry clean only. Store folded, away from direct light. Made to last for many seasons.' },
    { key: 'shipping', label: 'Shipping & Returns', body: 'Complimentary shipping within the region. Returns accepted within 30 days, unworn with tags.' },
  ];

  return (
    <div style={{ padding: '40px var(--gutter) 110px' }}>
      <button onClick={() => navigate('collection')} style={{ fontFamily: 'var(--font-sans)', fontSize: '11px', letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--shawn-taupe)', background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginBottom: '34px' }}>&larr; &nbsp;The Collection</button>

      <div style={{ display: 'grid', gridTemplateColumns: '1.15fr 1fr', gap: '64px', alignItems: 'start' }}>
        {/* Gallery */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ background: p.color, aspectRatio: '3 / 4', width: '100%' }}></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
            <div style={{ background: 'var(--shawn-bone)', aspectRatio: '1' }}></div>
            <div style={{ background: 'var(--shawn-stone)', aspectRatio: '1' }}></div>
            <div style={{ background: p.color, aspectRatio: '1', opacity: 0.7 }}></div>
          </div>
        </div>

        {/* Detail panel */}
        <div style={{ position: 'sticky', top: '110px' }}>
          <Eyebrow color="muted" style={{ marginBottom: '14px', display: 'block' }}>{p.category}</Eyebrow>
          <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: '40px', lineHeight: 1.1, margin: '0 0 12px', color: 'var(--shawn-ink)' }}>{p.name}</h1>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '18px', color: 'var(--shawn-espresso)', margin: '0 0 30px', letterSpacing: '0.02em' }}>{p.price}</p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: '15px', lineHeight: 1.7, color: 'var(--shawn-espresso)', margin: '0 0 34px', maxWidth: '420px' }}>{p.desc}</p>

          {/* Size */}
          <div style={{ marginBottom: '28px' }}>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: '10px', fontWeight: 500, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'var(--text-secondary)', marginBottom: '12px' }}>Size</div>
            <div style={{ display: 'flex', gap: '8px' }}>
              {sizes.map(s => (
                <button key={s} onClick={() => setSize(s)} style={{
                  fontFamily: 'var(--font-sans)', fontSize: '12px', letterSpacing: '0.06em', cursor: 'pointer',
                  width: '46px', height: '46px', borderRadius: 'var(--radius-md)',
                  border: `1px solid ${size === s ? 'var(--shawn-ink)' : 'var(--line-soft)'}`,
                  background: size === s ? 'var(--shawn-ink)' : 'transparent',
                  color: size === s ? 'var(--shawn-ivory)' : 'var(--text-primary)',
                  transition: 'all var(--dur-fast) var(--ease-standard)',
                }}>{s}</button>
              ))}
            </div>
          </div>

          <Button variant="primary" fullWidth onClick={() => addToBag(p, size)} style={{ marginBottom: '14px' }}>Add to Bag</Button>
          <Button variant="secondary" fullWidth>Book an Appointment</Button>

          {/* Accordion */}
          <div style={{ marginTop: '40px', borderTop: '1px solid var(--line-hairline)' }}>
            {accordion.map(a => (
              <div key={a.key} style={{ borderBottom: '1px solid var(--line-hairline)' }}>
                <button onClick={() => setOpen(open === a.key ? '' : a.key)} style={{
                  width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  background: 'none', border: 'none', cursor: 'pointer', padding: '20px 0',
                  fontFamily: 'var(--font-sans)', fontSize: '11px', fontWeight: 500, letterSpacing: '0.16em',
                  textTransform: 'uppercase', color: 'var(--shawn-ink)',
                }}>
                  {a.label}
                  <span style={{ fontSize: '16px', color: 'var(--shawn-taupe)' }}>{open === a.key ? '\u2212' : '+'}</span>
                </button>
                {open === a.key && (
                  <p style={{ fontFamily: 'var(--font-sans)', fontSize: '14px', lineHeight: 1.7, color: 'var(--shawn-espresso)', margin: '0 0 22px', maxWidth: '420px' }}>{a.body}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* You may also like */}
      <section style={{ marginTop: '120px' }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 400, fontSize: '28px', margin: '0 0 40px', color: 'var(--shawn-ink)', textAlign: 'center' }}>You may also like</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '28px' }}>
          {more.map(m => {
            const { ProductCard } = window.SHAWNDesignSystem_ef7ee7;
            return <ProductCard key={m.id} {...m} imageColor={m.color} onClick={() => navigate('product', m.id)} />;
          })}
        </div>
      </section>
    </div>
  );
}

window.Product = Product;
